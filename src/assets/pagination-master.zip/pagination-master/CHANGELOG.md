# 2.2.0

- Add prop `totalBoundaryShowSizeChanger`.
- Fix items count not being consistent. [#18201](https://github.com/ant-design/ant-design/issues/18201)
- Update default page size options from `10,25,50,100` to `10,20,50,100`.

# 2.1.0

- When `total` is greater then 100, will show size changer defaultly.
- Update default page size options from `10,20,30,40` to `10,25,50,100`.

# 2.0.0

- Remove `prop-types` and `react-lifecycles-compat`

  # 1.20.0

- Add locale `ms_MY`

  # 1.19.0

- Support Latvian localization

  # 1.18.0

- Support `disabled`

  # 1.17.0

- Add `prevIcon`, `nextIcon`, `jumpPrevIcon`, `jumpNextIcon`.

  # 1.16.1

- Add locale `sl_SI`. #130

  # 1.16.0

- Add locale `id_ID`
- Add prop `showPrevNextJumpers`

  # 1.15.2

- Add locale `tr_TR`.

  # 1.12.0

- `itemRender(current, type)` => `itemRender(current, type, element): element`.

  # 1.11.0

- Add `goButton`.

  # 1.10.0

- Add `itemRender`.

  # 1.9.0

- Add keyboard support
- Add es folder.

  # 1.8.0

- Add locale `zh_TW`.
- Add `showTitle`.

  # 1.7.5

- Add locale `sk_SK(Slovak)`.

  # 1.7.4

- Add locale `et_EE(Estonian)`.

  # 1.7.3

- Add locale `Czech`.

  # 1.7.2

- Add locale `ko_KR(Korean)`.

  # 1.7.1

- Add locale `ca_ES (Catalan)`.

  # 1.7.0

- support `showLessItems`. #55
- Add `pageSize` as onChange's second argument.

  # 1.6.0

- Add `range` as showTotal's second argument.

  # 1.5.5 / 2016-09-01

- Fix #34

  # 1.5.4 / 2016-07-31

- Add space before per page #33

  # 1.5.0 / 2016-03-02

- Add `defaultPageSize` and fix `pageSize` to a controlled prop

  # 1.3.0 / 2015-11-25

- Add `defaultCurrent` prop

  # 1.2.0

- Allow specifying the page size for **sizeChanger**
