export default {
  // Options.jsx
  items_per_page: '/старонка',
  jump_to: 'Перайсці',
  jump_to_confirm: 'Пацвердзіць',
  page: '',
  // Pagination.jsx
  prev_page: 'Назад',
  next_page: 'Наперад',
  prev_5: 'Папярэднія 5',
  next_5: 'Наступныя 5',
  prev_3: 'Папярэднія 3',
  next_3: 'Наступныя 3',
  page_size: 'памер старонкі',
};
