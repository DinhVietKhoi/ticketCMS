export default {
  // Options.jsx
  items_per_page: '/ ਪੰਨਾ',
  jump_to: 'Goto',
  jump_to_confirm: 'ਪੁਸ਼ਟੀ ਕਰੋ',
  page: 'ਪੰਨਾ',

  // Pagination.jsx
  prev_page: 'ਪਿਛਲਾ ਪੰਨਾ',
  next_page: 'ਅਗਲਾ ਪੰਨਾ',
  prev_5: 'ਪਿਛਲੇ 5 ਪੰਨੇ',
  next_5: 'ਅਗਲੇ 5 ਪੰਨੇ',
  prev_3: 'ਪਿਛਲੇ 3 ਪੰਨੇ',
  next_3: 'ਅਗਲੇ 3 ਪੰਨੇ',
  page_size: 'Page Size',
};
