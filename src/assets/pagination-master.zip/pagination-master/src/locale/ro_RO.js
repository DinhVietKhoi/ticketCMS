export default {
  // Options.jsx
  items_per_page: '/ pagină',
  jump_to: 'Mergi la',
  jump_to_confirm: 'confirm',
  page: '',

  // Pagination.jsx
  prev_page: 'Pagina Anterioară',
  next_page: 'Pagina Următoare',
  prev_5: '5 Pagini Anterioare',
  next_5: '5 Pagini Următoare',
  prev_3: '3 Pagini Anterioare',
  next_3: '3 Pagini Următoare',
  page_size: 'Page Size',
};
