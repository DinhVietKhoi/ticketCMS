## sizer

<code src="../examples/sizer.jsx">
