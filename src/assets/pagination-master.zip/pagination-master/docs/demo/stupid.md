## stupid

<code src="../examples/stupid.jsx">
