## locale

<code src="../examples/locale.jsx">
