## lessPages

<code src="../examples/lessPages.jsx">
