## simple

<code src="../examples/simple.jsx">
