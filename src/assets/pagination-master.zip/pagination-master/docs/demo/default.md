## default

<code src="../examples/default.jsx">
