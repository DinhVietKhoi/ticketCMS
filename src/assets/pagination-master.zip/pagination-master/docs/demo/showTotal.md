## showTotal

<code src="../examples/showTotal.jsx">
