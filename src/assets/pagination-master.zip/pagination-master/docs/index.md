---
title: rc-pagination
---

<embed src="../README.md"></embed>
